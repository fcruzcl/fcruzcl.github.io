package vrep_speech;
// red
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
// google voice
import info.knowledgeTechnology.docks.Data.Result;
import info.knowledgeTechnology.docks.Frontend.LocalMicrophone;
import info.knowledgeTechnology.docks.Frontend.VoiceActivityDetector;
import info.knowledgeTechnology.docks.PostProcessor.SentencelistPostProcessor;
import info.knowledgeTechnology.docks.Recognizer.RawGoogleRecognizer;
import info.knowledgeTechnology.docks.Utils.ConfigCreator;

public class Example {
	
	private static DatagramSocket getSocket() {
		DatagramSocket socket = null;
		try {
			socket = new DatagramSocket();
		} catch (SocketException e1) {
			e1.printStackTrace();
		}
		return socket;
	}

	private static InetAddress getDest() {
		InetAddress destination = null;
		try {
			destination = InetAddress.getByName("localhost");
		} catch (UnknownHostException e1) {
			e1.printStackTrace();
		}
		return destination;
	}

	private static void sendMessage(DatagramSocket socket, InetAddress destination,String s) {
		DatagramPacket packet;

		byte[] buffer = s.getBytes();

		//HOST, PORT = "134.100.10.137", 54013
		packet = new DatagramPacket(buffer, buffer.length, destination, 54013);

		try {
			socket.send(packet);
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
	
	// config folder
	public static void createConfigFolder()
	{
		String configname = "vrep";
		
		//this creates a new configuration in config/vrep/
		ConfigCreator.createConfigFolders(configname);
	}
	
	//testing your sentence list
	public static void voiceActivity()
	{
		String configname = "vrep";
		
		// load voice activity detection
		VoiceActivityDetector vac = new VoiceActivityDetector(
				new LocalMicrophone(), "LocalMicrophone");
		
		//initialize Google speech recognizer
		String key = "AIzaSyBOti4mM-6x9WDnZIjIeyEU21OpBXqWBgw";
		RawGoogleRecognizer rawGoogle = new RawGoogleRecognizer(key);
		
		//create a sentence list postprocessor
		SentencelistPostProcessor spc = new SentencelistPostProcessor(configname ,"docks_sentence_list.txt", 1);
		
		
		Result r;
		String rawGoogleResult;
		float rawGoogleConfidence;
		String sentenceListResult;
		float sentenceListConfidence;
		

		InetAddress dest = getDest();
		DatagramSocket socket = getSocket();
		
		while (true) {
			System.out.println("Recording...");
			
			rawGoogleResult = "";
			rawGoogleConfidence = 0.0f;
			sentenceListResult = "";
			sentenceListConfidence = 0.0f;
			
			//starts a recording at the voice activity detector and sends the audio data to Google
			//r contains the result coming from Google
			r = rawGoogle.recognize(vac);
			if(r!=null)
			{
				rawGoogleResult = r.getBestResult();
				rawGoogleConfidence = r.getConfidence();
				
				//now postprocess the result from google
				r = spc.recognizeFromResult(r);
				
				if(r!=null)
				{
					sentenceListResult = r.getBestResult();
					sentenceListConfidence = r.getConfidence();
				}
					
			}
			
			System.out.println("Raw Google: " + rawGoogleResult);
			System.out.println("Confidence: " + rawGoogleConfidence);
			System.out.println("Sentence List: " + sentenceListResult);
			System.out.println("Confidence: " + sentenceListConfidence);
			System.out.println("Sending V-REP");
			sendMessage(socket, dest, sentenceListResult);
		}
		
		
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		createConfigFolder();
		voiceActivity();
	}

}