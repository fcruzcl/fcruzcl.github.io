#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Sun Dec  2 19:52:38 2018

@author: angel4ayala
"""


from Tkinter import Tk, Label, Button, Frame
import Interaction
from threading import Thread

class TkinterGUIThread(Thread):
    def run(self):
        root = Tk()
        my_gui = TkinterGUI(root)
        root.mainloop()
        root.destroy()

class TkinterGUI(Frame):
    
    def __init__(self, master=None):
        Frame.__init__(self, master)
        master.title("Interactive Reinforcement Learning")
        self.pack()
        self.createButtons()
        
    def createButtons(self):
        
        self.label_1 = Label(self, text="Please, select an action if you want to advise the robot:")
        self.label_1.pack()
        
        
        self.getTheCupButton = Button(self, text="Get the cup", command=self.getTheCupPush)
        self.getTheCupButton.pack()
        
        self.dropTheCupButton = Button(self, text="Drop the cup", command=self.dropTheCupPush)
        self.dropTheCupButton.pack()
        
        self.label_2 = Label(self, text="")
        self.label_2.pack()
        
        self.getTheSpongeButton = Button(self, text="Get the sponge", command=self.getTheSpongePush)
        self.getTheSpongeButton.pack()
        
        self.dropTheSpongeButton = Button(self, text="Drop the sponge", command=self.dropTheSpongePush)
        self.dropTheSpongeButton.pack()
        
        self.label_3 = Label(self, text="")
        self.label_3.pack()
        
        self.goLeftButton = Button(self, text="Go left", command=self.goLeftPush)
        self.goLeftButton.pack()
        
        self.goRightButton = Button(self, text="Go right", command=self.goRightPush)
        self.goRightButton.pack()
        
        self.goHomeButton = Button(self, text="Go home", command=self.goHomePush)
        self.goHomeButton.pack()
        
        self.label_4 = Label(self, text="")
        self.label_4.pack()
                
        self.cleanButton = Button(self, text="Clean", command=self.cleanPush)
        self.cleanButton.pack()
        
        self.label_5 = Label(self, text="")
        self.label_5.pack()
        
        self.close_button = Button(self, text="Salir", command=self.exitPush)
        self.close_button.pack()
        
    def getTheSpongePush(self):#, event):  # wxGlade: MyFrame.<event_handler>
        Interaction.buttonPush = 0        
#        event.Skip()

    def getTheCupPush(self):#, event):  # wxGlade: MyFrame.<event_handler>
        Interaction.buttonPush = 1        
#        event.Skip()

    def dropTheSpongePush(self):#, event):  # wxGlade: MyFrame.<event_handler>
        Interaction.buttonPush = 2        
#        event.Skip()

    def dropTheCupPush(self):#, event):  # wxGlade: MyFrame.<event_handler>
        Interaction.buttonPush = 3        
#        event.Skip()

    def goHomePush(self):#, event):  # wxGlade: MyFrame.<event_handler>
        Interaction.buttonPush = 4        
#        event.Skip()

    def goLeftPush(self):#, event):  # wxGlade: MyFrame.<event_handler>
        Interaction.buttonPush = 5
#        event.Skip()

    def goRightPush(self):#, event):  # wxGlade: MyFrame.<event_handler>
        Interaction.buttonPush = 6
#        event.Skip()
        
    def cleanPush(self):#, event):  # wxGlade: MyFrame.<event_handler>
        Interaction.buttonPush = 7        
#        event.Skip()
        
    def exitPush(self):
        Interaction.buttonPush = -1
        Interaction.run = False
        self.quit()
