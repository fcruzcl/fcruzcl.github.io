# -*- coding: utf-8 -*-
"""
Created on Wed May 13 17:56:13 2015

@author: cruz
"""

import numpy as np

class Teacher(object):
    def __init__(self):
        self.advice = [1,7,1,6,2,5,7,8,7,5,6,6,8,4,6,3,1,6,2,5,5,8,7,5,6,6,5,4,1,7,7,3,5,7,7,5,4,2,5,5,8,6,5,5,3,0]
    #en of __init__ method
    
    def getAdvice(self, state, referenceFile):
        actionCode = self.advice[state]
    
        sentenceFile=open('sentenceList.txt','r')
        actionFile=open('actionList.txt','r')
    
        sentenceLine = sentenceFile.readline()
        actionLine = actionFile.readline()
    
        listOfSentences = []
    
        #Fill one array with variations of the sentence
        while actionLine != "":
            if int(actionLine) == actionCode:
                listOfSentences.append(sentenceLine.split('\n')[0])
                
            sentenceLine=sentenceFile.readline()
            actionLine=actionFile.readline()
        
        #Select an alternative for giving the advice
        lenght = len(listOfSentences)
        actionSelected = np.random.randint(lenght)
        sentence = listOfSentences[actionSelected]
    
        sentenceFile.close()
        actionFile.close()    
        
        #Look up for the returned sentence by DOCKS
        hypFile=open(referenceFile, 'r')
        hypLine = hypFile.readline()
    
        while hypLine != "":
            hypLineCut =  hypLine.split(';')[0]
            if hypLineCut == sentence:
                returnedSentence = hypLine.split(';')[1]
    
            hypLine=hypFile.readline()

        #Loop up for the code of the returned sentence
        sentenceFile=open('sentenceList.txt','r')
        actionFile=open('actionList.txt','r')
    
        sentenceLine = sentenceFile.readline()
        actionLine = actionFile.readline()
    
        while sentenceLine != "":
            sentenceLineCut = sentenceLine.split(';')[0]
            if sentenceLineCut == returnedSentence:
                actionReturned = int(actionLine)
                
            sentenceLine=sentenceFile.readline()
            actionLine=actionFile.readline()
        
        #print 'actionCode: ' + str(actionCode)
        #print 'actionReturned: ' + str(actionReturned)
    
        return actionReturned - 1
    #end of getAdvice method
        
    def actionToCode(self, sentence):
        #Loop up for the code of the returned sentence
        sentenceFile=open('classes/sentenceList.txt','r')
        actionFile=open('classes/actionList.txt','r')
        actionReturned = -1
    
        sentenceLine = sentenceFile.readline()
        actionLine = actionFile.readline()
        
        while sentenceLine != "":
            sentenceLineCut = sentenceLine.split(';')[0]
            if sentenceLineCut == sentence:
                actionReturned = int(actionLine)
                
            sentenceLine=sentenceFile.readline()
            actionLine=actionFile.readline()
        
        return actionReturned - 1
    #end of actionToCode method      

#end of class Teacher
"""
if __name__ == "__main__":
    teacher = Teacher()
    code = teacher.actionToCode('clean the table\n')
    print code
"""
