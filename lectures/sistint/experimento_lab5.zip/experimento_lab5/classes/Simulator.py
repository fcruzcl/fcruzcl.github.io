# -*- coding: utf-8 -*-
"""
Created on Tue Mar 10 16:12:18 2015

@author: cruz
"""

import vrep
import math

class Simulator(object):

    def __init__(self):
        self.clientID = self.connectRobot()
        if self.clientID != -1:
            self.actionNumber = 1
            #self.performAnAction(4) #go home
        #endif
    #end of __init__ method

    def connectRobot(self):
        clientID=vrep.simxStart('127.0.0.1',19997,True,False,5000,5)
        if clientID!=-1:
            print 'Connected to remote API server with clientID: ', clientID
            vrep.simxStartSimulation(clientID, vrep.simx_opmode_oneshot_wait)
        else:
            print 'Failed connecting to remote API server'

        return clientID
    #end of connectRobot method
    
    def disconnectSimulator(self):
        vrep.simxStopSimulation(self.clientID, vrep.simx_opmode_oneshot_wait)
        vrep.simxFinish(self.clientID)
        print 'Robot and simulator disconnected'
    #end of disconnectSimulator method

    def restartScenario(self):
        self.performAnAction(100)
    #end of disconnectRobot method
    
    def performAnAction(self, action):
        vrep.simxSetIntegerSignal(self.clientID,"codeToAction",action+1,vrep.simx_opmode_oneshot)
        self.waitForResponse()
        self.actionNumber+=1
    #end of performAnAction method
    
    def waitForResponse(self):
        action = 0
        errorCode, action=vrep.simxGetIntegerSignal(self.clientID, "actionPerformed", vrep.simx_opmode_streaming)
        #i = 0
        while action < self.actionNumber:
            errorCode, action=vrep.simxGetIntegerSignal(self.clientID, "actionPerformed", vrep.simx_opmode_buffer)
    #end of waitForResponse method

    def moveJoint(self, jointToMove, angle):
        errorCode, handleJoint = vrep.simxGetObjectHandle(self.clientID, jointToMove, vrep.simx_opmode_oneshot_wait)
        if errorCode==vrep.simx_error_noerror:
            vrep.simxSetJointTargetPosition(self.clientID, handleJoint, angle, vrep.simx_opmode_oneshot)
        else:
            print 'Error. Got no handle: ', errorCode
    #end of moveJoint method
            
    def getPosOriented(self, handle):
        errorCode, pos = vrep.simxGetObjectPosition(self.clientID, handle, -1, vrep.simx_opmode_streaming)
        errorCode, oriented = vrep.simxGetObjectOrientation(self.clientID, handle, -1, vrep.simx_opmode_streaming)
        return pos, oriented
    #end of getPosOriented
    
            
if __name__ == "__main__":
    simulator = Simulator()
    clientID = simulator.clientID
    errorCode, handle = vrep.simxGetObjectHandle(clientID, 'Right_Dummy_Target#', vrep.simx_opmode_oneshot_wait)
    #raw_input("Pulsa una tecla para continuar...") 
    
    pos, oriented = simulator.getPosOriented(handle)

    print pos
    print oriented
    
    

    #vrep.simxSetObjectPosition(clientID, handle, -1, [-0.15,-0.0224,0.35], vrep.simx_opmode_oneshot)
    #vrep.simxSetObjectPosition(clientID, handle, -1, [-0.15,-0.2,0.2906], vrep.simx_opmode_oneshot)
    #vrep.simxSetObjectOrientation(clientID, handle, -1, [-math.pi/2, 0, 0], vrep.simx_opmode_oneshot)

    #raw_input("Pulsa una tecla para continuar...") 

    simulator.moveJoint('Right_Grip#', -math.pi/2)

    print 'The end'
    
    
    
    

    
    
    
    

#end of class Simulator
