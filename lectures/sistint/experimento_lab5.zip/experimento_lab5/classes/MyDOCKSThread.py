# -*- coding: utf-8 -*-
"""
Created on Tue May 19 16:03:27 2015

@author: cruz
"""

import SocketServer
import Interaction
from threading import Thread

class MyDOCKSThread(Thread):
    def run(self):
        print "The DOCKS server is now running..."
        #HOST, PORT = "134.100.10.137", 54013
        #HOST, PORT = "134.100.10.223", 54013
        HOST, PORT = "localhost", 54013
        server = SocketServer.UDPServer((HOST, PORT), MyUDPHandler)
        server.serve_forever()        
        
        
class MyUDPHandler(SocketServer.BaseRequestHandler):

    def handle(self):
        data = self.request[0].strip()
        #socket = self.request[1]
        #print "{} wrote:".format(self.client_address[0])
        #print data
        Interaction.sentence = data+"\n"
        #print "***"+Interaction.sentence+"***"
        #socket.sendto(data.upper(), self.client_address)
