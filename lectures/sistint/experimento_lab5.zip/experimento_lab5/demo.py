# -*- coding: utf-8 -*-
"""
Created on Wed Nov 20 12:43:35 2013

@author: cruz
* version 0.2: this version takes into account concept of affordances and
select only actions which do not produce a catastrophic state
Graphs are builded to show number of steps in each iteration.
Graphs sent to Prof. Wermter.

* version 0.3: introduce a second agent trainer interaction showing one path.
The results are not so good.

* version 0.4: introduce a probability to give interaction. That is, using 
the same training algorithm to give feedback just in some episodes.

* vesion 0.4.1: sim reviewed and train() returns numbers of steps for ploting
two variables in the same figure.

This version was used to create the file in Interactive RL + Affordances
scenario which is used to make the plot after. That plot was used in 
ICDL-EpiRob paper.

The plots are created using the script called makePlot2 (function plot2) 
where this approach is compared with reinforcement learning + affondances 
scenario

A future improvement would be to save every single produced data and thus
not using the averaged data anymore. Another option could be create different
files that means dont overwrite them, or develop a short script to analize
those data.

"""
#Libraries Declaration
#from classes.MyGUIThread import MyGUIThread
from classes.MyDOCKSThread import MyDOCKSThread
from classes.TkinterGUI import TkinterGUIThread
from classes.Simulator import Simulator
from classes.Scenario import Scenario
from classes.Agent import Agent


#main
def main():
    
    print "Interactive RL DEMO for cleaning a table is running ... "
    
    #!!!!!!!!!!!!!!!!!!
    demoToShow = 1 #1: Movements, 2:RL+Interaction    !!!!!!!!!!!!
    interactionMode = 1 #0: None, 1 uses GUI for interaction, 2 uses DOCKS !!!!!!!!!!
    #!!!!!!!!!!!!!!!!!!
    
    iter = 1
    affordances = 1 #1: RL + Affordances, 0: Autonomous RL
    showSimulator = 1 #1 uses v-rep user interface, 0 doesn't use it

    if interactionMode == 1:
#        myGUI = MyGUIThread()
        myGUI = TkinterGUIThread()
        myGUI.start()
        
    if interactionMode == 2:
        myDOCKS = MyDOCKSThread()
        myDOCKS.start()

    if showSimulator == 1:
        simulator = Simulator()
    else:
        simulator = None


    scenario = Scenario()
    apprenticeAgent = Agent(scenario, simulator)
    if demoToShow == 1:
        apprenticeAgent.demoMovement(interactionMode)
    else:
        apprenticeAgent.trainDemo(iter, affordances, interactionMode, showSimulator)

    if showSimulator == 1:
        simulator.disconnectSimulator()

    print "The end"

# end of main method

if __name__ == "__main__":
    main()
